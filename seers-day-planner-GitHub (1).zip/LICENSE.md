# LICENSE

© 2025 SEERS DAY PLANNER  
All rights reserved.

This software is proprietary and is not licensed for redistribution, reverse engineering, commercial resale, or unauthorized copying.

## Disclaimer
This planner is for **entertainment purposes only**. It is not intended to diagnose, treat, cure, or prevent any disease, nor is it a substitute for professional, legal, medical, or financial advice.

By using this application, you acknowledge and agree to use it at your own discretion.
